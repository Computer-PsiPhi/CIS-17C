package testwedding;

/**
 * File: Couple.java
 * Written by Noel Perez
 * Written on 9/14/23
 */

public class Couple {
    
  // Couple fields for groom and bride 
  private Person groom;
  private Person bride; 
    
  // Constructor with 2 parameters for Couple class
  public Couple(Person husband, Person wife ){
       this.groom = husband;
        this.bride = wife; 
    }
    
  // Accessor and Mutator Methods of Couple class
  public Person getGroom(){
      return groom; 
  }  
  public void setGroom(Person male){
      groom = male; 
  }

  public Person getBride(){
      return bride; 
  }  
  public void setBride(Person female){
      bride = female; 
  }
  
}
