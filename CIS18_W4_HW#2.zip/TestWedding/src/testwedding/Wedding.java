package testwedding;
import java.time.*;

/**
 * File: Wedding.java
 * Written by Noel Perez
 * Written on 9/14/23
 */

public class Wedding {
    
 // Class fields: a couple, wedding date and the location of the couple's wedding
    private Couple couple; 
    private LocalDate dateWedding; 
    private String location;
  
    // Constructor with 3 parameters for Wedding class 
    public Wedding(Couple aCouple , LocalDate dateWed, String loc){
      
        this.couple = aCouple;
        this.dateWedding = dateWed;
        this.location = loc;
    }
    
    // Accessor and Mutator methods for Wedding class
    public Couple getCouple(){
        return couple;
    }
    public void setCouple(Couple oneCouple){
        couple = oneCouple; 
    }
    
    public LocalDate getWedDate(){
        return dateWedding;
    }
    public void setWedDate(LocalDate dateWed){
        dateWedding = dateWed;
    }
    
    public String getLocation(){
        return location; 
    }
    public void setLocation(String loc){
        location = loc;
    }
            
}
