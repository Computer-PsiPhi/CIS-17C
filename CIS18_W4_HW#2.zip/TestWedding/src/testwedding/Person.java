package testwedding;
import java.time.*;

/**
 * File: Person.java
 * Written by Noel Perez
 * Written on 9/14/23
 */

public class Person {
    
    // Class fields: for complete name and birthdate 
    private String firstName;
    private String lastName;
    private LocalDate birthDate; 
    
    // 3 Parameter Constructor for Person class
    public Person(String firstN, String lastN, LocalDate bDay ){
       this.firstName = firstN;
        this.lastName = lastN;
        this.birthDate = bDay; 
        
    };
  
    // Accessor and Mutator Methods for class fields 
    public String getFirstName(){
        return firstName; 
    }
    public void setFirstName(String firstN){
        firstName = firstN; 
    }
    
    public String getLastName(){
        return lastName;
    }
    public void getLastName(String lastN){
        lastName = lastN;
    }
    
    public LocalDate getBirthDate(){
        return birthDate; 
    }
   public void setBirthDate(LocalDate bDay){
       birthDate = bDay; 
   }
   
}
