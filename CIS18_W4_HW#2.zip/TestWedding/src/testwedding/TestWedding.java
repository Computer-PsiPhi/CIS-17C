
package testwedding;
import java.time.*;

/** Page 226 - Exercise  #11
 * File: TestWedding.java
 * Written by Noel Perez
 * Written on 9/14/23
 */
public class TestWedding {

   
    public static void main(String[] args) {
        
       // 4 Person object declarations to make 2 couples. Constructors have 3 parameters: first name, last name, and birthdate 
        Person husbandOne = new Person("John ","Maple", LocalDate.of(2000, Month.MARCH, 22));
        Person wifeOne = new Person("Ashley ","Smith", LocalDate.of(2001, Month.JULY, 1));
        Person husbandTwo = new Person("Mark ","Otto", LocalDate.of(2002, Month.JUNE, 7));
        Person wifeTwo =new Person("Sarah ","Topple", LocalDate.of(2003, Month.NOVEMBER, 11));
      
       // Two Couple object declarations made form 4 Persons. Constructor has 2 parameters: husband and wife 
        Couple coupleOne = new Couple(husbandOne, wifeOne);
        Couple coupleTwo = new Couple(husbandTwo, wifeTwo);
        
       // Two Wedding Objects declarations with one couple, wedding date, and location of wedding passed in to constructor
        Wedding nupitalOne = new Wedding(coupleOne, LocalDate.of(2024,4,1), "Paris, France");
        Wedding nupitalTwo = new Wedding(coupleTwo, LocalDate.of(2025,4,1), "Central Park, New York");
      
        System.out.println("Wedding Details:"); // Prompt
         
        // Display method for displaying class details
        displayDetails(nupitalOne);
        displayDetails(nupitalTwo);
        
    }
    
    // Method definition: Displays wedding details/fields 
    public static void displayDetails(Wedding aWedding){
        
       System.out.println("--------------------------------------");
 
       // Output groom details
        System.out.println("Groom: " +
                            aWedding.getCouple().getGroom().getFirstName() +
                            aWedding.getCouple().getGroom().getLastName() +
                            ", born " +
                            aWedding.getCouple().getGroom().getBirthDate() 
                            );
        
        // Output bride detials
        System.out.println("Bride: " + 
                            aWedding.getCouple().getBride().getFirstName() +
                            aWedding.getCouple().getBride().getLastName() +
                            ", born " +
                            aWedding.getCouple().getBride().getBirthDate()
                           );
        
        // Output wedding date and location 
        System.out.println("Date of wedding: " +
                            aWedding.getWedDate()+ "\n"+
                            "Location: "+
                            aWedding.getLocation() 
                            
                            );
       
    }
}
